import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;


@RunWith(JUnit4.class)
public class CompetitionTests {

    public static String filename = "tinyEWD.txt";
    public static final int speedA = 50;
    public static final int speedB = 75;
    public static final int speedC = 100;

    @Test
    public void testDijkstraConstructor() {

        CompetitionDijkstra test = new CompetitionDijkstra(filename, speedA, speedB, speedC);
        System.out.println("Time: " + test.timeRequiredforCompetition());
    }

    @Test
    public void testFWConstructor() {
        //TODO
    }

    //TODO - more tests

}
